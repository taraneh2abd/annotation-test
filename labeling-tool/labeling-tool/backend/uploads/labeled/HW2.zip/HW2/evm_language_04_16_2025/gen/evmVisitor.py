# Generated from D:/PhD/Classes/Compiler_1403_2/projects/evm_language_prototype/out/evm.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .evmParser import evmParser
else:
    from evmParser import evmParser

# This class defines a complete generic visitor for a parse tree produced by evmParser.

class evmVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by evmParser#program.
    def visitProgram(self, ctx:evmParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#statements.
    def visitStatements(self, ctx:evmParser.StatementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#statement.
    def visitStatement(self, ctx:evmParser.StatementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#if_statement.
    def visitIf_statement(self, ctx:evmParser.If_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#while_statement.
    def visitWhile_statement(self, ctx:evmParser.While_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#for_statement.
    def visitFor_statement(self, ctx:evmParser.For_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#for_increment.
    def visitFor_increment(self, ctx:evmParser.For_incrementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#for_intialization.
    def visitFor_intialization(self, ctx:evmParser.For_intializationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#block_statement.
    def visitBlock_statement(self, ctx:evmParser.Block_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#condition.
    def visitCondition(self, ctx:evmParser.ConditionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#comparison_statement.
    def visitComparison_statement(self, ctx:evmParser.Comparison_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#bool.
    def visitBool(self, ctx:evmParser.BoolContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#variable_declartion.
    def visitVariable_declartion(self, ctx:evmParser.Variable_declartionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#variable_assignment.
    def visitVariable_assignment(self, ctx:evmParser.Variable_assignmentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#variable_type.
    def visitVariable_type(self, ctx:evmParser.Variable_typeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#expression.
    def visitExpression(self, ctx:evmParser.ExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#term.
    def visitTerm(self, ctx:evmParser.TermContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#factor.
    def visitFactor(self, ctx:evmParser.FactorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#id.
    def visitId(self, ctx:evmParser.IdContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#print_variable.
    def visitPrint_variable(self, ctx:evmParser.Print_variableContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#int.
    def visitInt(self, ctx:evmParser.IntContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#float.
    def visitFloat(self, ctx:evmParser.FloatContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by evmParser#string.
    def visitString(self, ctx:evmParser.StringContext):
        return self.visitChildren(ctx)



del evmParser