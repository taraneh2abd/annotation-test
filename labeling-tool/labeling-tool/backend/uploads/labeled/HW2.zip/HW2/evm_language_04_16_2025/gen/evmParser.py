# Generated from D:/PhD/Classes/Compiler_1403_2/projects/evm_language_prototype/out/evm.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,27,165,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,1,0,1,0,1,0,1,1,4,1,47,8,1,11,1,12,1,48,1,2,1,2,1,2,1,2,1,2,
        1,2,3,2,57,8,2,1,3,1,3,1,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,
        5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,7,1,7,1,8,1,
        8,1,8,1,8,1,9,1,9,3,9,92,8,9,1,10,1,10,3,10,96,8,10,1,10,1,10,1,
        10,3,10,101,8,10,1,11,1,11,1,12,1,12,1,12,1,12,1,12,3,12,110,8,12,
        1,13,1,13,1,13,1,13,3,13,116,8,13,1,14,1,14,1,15,1,15,1,15,1,15,
        1,15,1,15,5,15,126,8,15,10,15,12,15,129,9,15,1,16,1,16,1,16,1,16,
        1,16,1,16,5,16,137,8,16,10,16,12,16,140,9,16,1,17,1,17,1,17,1,17,
        1,17,1,17,3,17,148,8,17,1,18,1,18,1,19,1,19,1,19,1,19,3,19,156,8,
        19,1,19,1,19,1,20,1,20,1,20,3,20,163,8,20,1,20,0,2,30,32,21,0,2,
        4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,0,4,1,0,10,
        11,1,0,13,15,1,0,16,17,1,0,18,19,161,0,42,1,0,0,0,2,46,1,0,0,0,4,
        56,1,0,0,0,6,58,1,0,0,0,8,64,1,0,0,0,10,70,1,0,0,0,12,80,1,0,0,0,
        14,83,1,0,0,0,16,85,1,0,0,0,18,91,1,0,0,0,20,95,1,0,0,0,22,102,1,
        0,0,0,24,104,1,0,0,0,26,111,1,0,0,0,28,117,1,0,0,0,30,119,1,0,0,
        0,32,130,1,0,0,0,34,147,1,0,0,0,36,149,1,0,0,0,38,151,1,0,0,0,40,
        162,1,0,0,0,42,43,3,2,1,0,43,44,5,0,0,1,44,1,1,0,0,0,45,47,3,4,2,
        0,46,45,1,0,0,0,47,48,1,0,0,0,48,46,1,0,0,0,48,49,1,0,0,0,49,3,1,
        0,0,0,50,57,3,24,12,0,51,57,3,38,19,0,52,57,3,6,3,0,53,57,3,8,4,
        0,54,57,3,10,5,0,55,57,3,26,13,0,56,50,1,0,0,0,56,51,1,0,0,0,56,
        52,1,0,0,0,56,53,1,0,0,0,56,54,1,0,0,0,56,55,1,0,0,0,57,5,1,0,0,
        0,58,59,5,1,0,0,59,60,5,2,0,0,60,61,3,18,9,0,61,62,5,3,0,0,62,63,
        3,16,8,0,63,7,1,0,0,0,64,65,5,4,0,0,65,66,5,2,0,0,66,67,3,18,9,0,
        67,68,5,3,0,0,68,69,3,16,8,0,69,9,1,0,0,0,70,71,5,5,0,0,71,72,5,
        2,0,0,72,73,3,14,7,0,73,74,5,6,0,0,74,75,3,18,9,0,75,76,5,6,0,0,
        76,77,3,12,6,0,77,78,5,3,0,0,78,79,3,16,8,0,79,11,1,0,0,0,80,81,
        3,36,18,0,81,82,5,7,0,0,82,13,1,0,0,0,83,84,3,24,12,0,84,15,1,0,
        0,0,85,86,5,8,0,0,86,87,3,2,1,0,87,88,5,9,0,0,88,17,1,0,0,0,89,92,
        3,22,11,0,90,92,3,20,10,0,91,89,1,0,0,0,91,90,1,0,0,0,92,19,1,0,
        0,0,93,96,3,36,18,0,94,96,3,40,20,0,95,93,1,0,0,0,95,94,1,0,0,0,
        96,97,1,0,0,0,97,100,5,24,0,0,98,101,3,36,18,0,99,101,3,40,20,0,
        100,98,1,0,0,0,100,99,1,0,0,0,101,21,1,0,0,0,102,103,7,0,0,0,103,
        23,1,0,0,0,104,105,3,28,14,0,105,106,3,36,18,0,106,109,5,12,0,0,
        107,110,3,40,20,0,108,110,3,30,15,0,109,107,1,0,0,0,109,108,1,0,
        0,0,110,25,1,0,0,0,111,112,3,36,18,0,112,115,5,12,0,0,113,116,3,
        40,20,0,114,116,3,30,15,0,115,113,1,0,0,0,115,114,1,0,0,0,116,27,
        1,0,0,0,117,118,7,1,0,0,118,29,1,0,0,0,119,120,6,15,-1,0,120,121,
        3,32,16,0,121,127,1,0,0,0,122,123,10,2,0,0,123,124,7,2,0,0,124,126,
        3,32,16,0,125,122,1,0,0,0,126,129,1,0,0,0,127,125,1,0,0,0,127,128,
        1,0,0,0,128,31,1,0,0,0,129,127,1,0,0,0,130,131,6,16,-1,0,131,132,
        3,34,17,0,132,138,1,0,0,0,133,134,10,2,0,0,134,135,7,3,0,0,135,137,
        3,34,17,0,136,133,1,0,0,0,137,140,1,0,0,0,138,136,1,0,0,0,138,139,
        1,0,0,0,139,33,1,0,0,0,140,138,1,0,0,0,141,148,3,36,18,0,142,148,
        3,40,20,0,143,144,5,2,0,0,144,145,3,30,15,0,145,146,5,3,0,0,146,
        148,1,0,0,0,147,141,1,0,0,0,147,142,1,0,0,0,147,143,1,0,0,0,148,
        35,1,0,0,0,149,150,5,25,0,0,150,37,1,0,0,0,151,152,5,20,0,0,152,
        155,5,2,0,0,153,156,3,40,20,0,154,156,3,36,18,0,155,153,1,0,0,0,
        155,154,1,0,0,0,156,157,1,0,0,0,157,158,5,3,0,0,158,39,1,0,0,0,159,
        163,5,21,0,0,160,163,5,22,0,0,161,163,5,23,0,0,162,159,1,0,0,0,162,
        160,1,0,0,0,162,161,1,0,0,0,163,41,1,0,0,0,12,48,56,91,95,100,109,
        115,127,138,147,155,162
    ]

class evmParser ( Parser ):

    grammarFileName = "evm.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'if'", "'('", "')'", "'while'", "'for'", 
                     "';'", "'++'", "'{'", "'}'", "'True'", "'False'", "'='", 
                     "'int'", "'float'", "'string'", "'+'", "'-'", "'*'", 
                     "'/'", "'print'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "INT", "FLOAT", "STRING", "RELATIONAL_OPERATOR", 
                      "ID", "WS", "NEWLINE" ]

    RULE_program = 0
    RULE_statements = 1
    RULE_statement = 2
    RULE_if_statement = 3
    RULE_while_statement = 4
    RULE_for_statement = 5
    RULE_for_increment = 6
    RULE_for_intialization = 7
    RULE_block_statement = 8
    RULE_condition = 9
    RULE_comparison_statement = 10
    RULE_bool = 11
    RULE_variable_declartion = 12
    RULE_variable_assignment = 13
    RULE_variable_type = 14
    RULE_expression = 15
    RULE_term = 16
    RULE_factor = 17
    RULE_id = 18
    RULE_print_variable = 19
    RULE_value = 20

    ruleNames =  [ "program", "statements", "statement", "if_statement", 
                   "while_statement", "for_statement", "for_increment", 
                   "for_intialization", "block_statement", "condition", 
                   "comparison_statement", "bool", "variable_declartion", 
                   "variable_assignment", "variable_type", "expression", 
                   "term", "factor", "id", "print_variable", "value" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    INT=21
    FLOAT=22
    STRING=23
    RELATIONAL_OPERATOR=24
    ID=25
    WS=26
    NEWLINE=27

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statements(self):
            return self.getTypedRuleContext(evmParser.StatementsContext,0)


        def EOF(self):
            return self.getToken(evmParser.EOF, 0)

        def getRuleIndex(self):
            return evmParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = evmParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            self.statements()
            self.state = 43
            self.match(evmParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(evmParser.StatementContext)
            else:
                return self.getTypedRuleContext(evmParser.StatementContext,i)


        def getRuleIndex(self):
            return evmParser.RULE_statements

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatements" ):
                listener.enterStatements(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatements" ):
                listener.exitStatements(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatements" ):
                return visitor.visitStatements(self)
            else:
                return visitor.visitChildren(self)




    def statements(self):

        localctx = evmParser.StatementsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statements)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 45
                self.statement()
                self.state = 48 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 34660402) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_declartion(self):
            return self.getTypedRuleContext(evmParser.Variable_declartionContext,0)


        def print_variable(self):
            return self.getTypedRuleContext(evmParser.Print_variableContext,0)


        def if_statement(self):
            return self.getTypedRuleContext(evmParser.If_statementContext,0)


        def while_statement(self):
            return self.getTypedRuleContext(evmParser.While_statementContext,0)


        def for_statement(self):
            return self.getTypedRuleContext(evmParser.For_statementContext,0)


        def variable_assignment(self):
            return self.getTypedRuleContext(evmParser.Variable_assignmentContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = evmParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_statement)
        try:
            self.state = 56
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [13, 14, 15]:
                self.enterOuterAlt(localctx, 1)
                self.state = 50
                self.variable_declartion()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 2)
                self.state = 51
                self.print_variable()
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 3)
                self.state = 52
                self.if_statement()
                pass
            elif token in [4]:
                self.enterOuterAlt(localctx, 4)
                self.state = 53
                self.while_statement()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 5)
                self.state = 54
                self.for_statement()
                pass
            elif token in [25]:
                self.enterOuterAlt(localctx, 6)
                self.state = 55
                self.variable_assignment()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class If_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def condition(self):
            return self.getTypedRuleContext(evmParser.ConditionContext,0)


        def block_statement(self):
            return self.getTypedRuleContext(evmParser.Block_statementContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_if_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf_statement" ):
                listener.enterIf_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf_statement" ):
                listener.exitIf_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIf_statement" ):
                return visitor.visitIf_statement(self)
            else:
                return visitor.visitChildren(self)




    def if_statement(self):

        localctx = evmParser.If_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_if_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 58
            self.match(evmParser.T__0)
            self.state = 59
            self.match(evmParser.T__1)
            self.state = 60
            self.condition()
            self.state = 61
            self.match(evmParser.T__2)
            self.state = 62
            self.block_statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class While_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def condition(self):
            return self.getTypedRuleContext(evmParser.ConditionContext,0)


        def block_statement(self):
            return self.getTypedRuleContext(evmParser.Block_statementContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_while_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile_statement" ):
                listener.enterWhile_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile_statement" ):
                listener.exitWhile_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhile_statement" ):
                return visitor.visitWhile_statement(self)
            else:
                return visitor.visitChildren(self)




    def while_statement(self):

        localctx = evmParser.While_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_while_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 64
            self.match(evmParser.T__3)
            self.state = 65
            self.match(evmParser.T__1)
            self.state = 66
            self.condition()
            self.state = 67
            self.match(evmParser.T__2)
            self.state = 68
            self.block_statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def for_intialization(self):
            return self.getTypedRuleContext(evmParser.For_intializationContext,0)


        def condition(self):
            return self.getTypedRuleContext(evmParser.ConditionContext,0)


        def for_increment(self):
            return self.getTypedRuleContext(evmParser.For_incrementContext,0)


        def block_statement(self):
            return self.getTypedRuleContext(evmParser.Block_statementContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_for_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_statement" ):
                listener.enterFor_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_statement" ):
                listener.exitFor_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor_statement" ):
                return visitor.visitFor_statement(self)
            else:
                return visitor.visitChildren(self)




    def for_statement(self):

        localctx = evmParser.For_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_for_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 70
            self.match(evmParser.T__4)
            self.state = 71
            self.match(evmParser.T__1)
            self.state = 72
            self.for_intialization()
            self.state = 73
            self.match(evmParser.T__5)
            self.state = 74
            self.condition()
            self.state = 75
            self.match(evmParser.T__5)
            self.state = 76
            self.for_increment()
            self.state = 77
            self.match(evmParser.T__2)
            self.state = 78
            self.block_statement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_incrementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(evmParser.IdContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_for_increment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_increment" ):
                listener.enterFor_increment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_increment" ):
                listener.exitFor_increment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor_increment" ):
                return visitor.visitFor_increment(self)
            else:
                return visitor.visitChildren(self)




    def for_increment(self):

        localctx = evmParser.For_incrementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_for_increment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.id_()
            self.state = 81
            self.match(evmParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_intializationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_declartion(self):
            return self.getTypedRuleContext(evmParser.Variable_declartionContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_for_intialization

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_intialization" ):
                listener.enterFor_intialization(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_intialization" ):
                listener.exitFor_intialization(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor_intialization" ):
                return visitor.visitFor_intialization(self)
            else:
                return visitor.visitChildren(self)




    def for_intialization(self):

        localctx = evmParser.For_intializationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_for_intialization)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 83
            self.variable_declartion()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Block_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statements(self):
            return self.getTypedRuleContext(evmParser.StatementsContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_block_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBlock_statement" ):
                listener.enterBlock_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBlock_statement" ):
                listener.exitBlock_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBlock_statement" ):
                return visitor.visitBlock_statement(self)
            else:
                return visitor.visitChildren(self)




    def block_statement(self):

        localctx = evmParser.Block_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_block_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.match(evmParser.T__7)
            self.state = 86
            self.statements()
            self.state = 87
            self.match(evmParser.T__8)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def bool_(self):
            return self.getTypedRuleContext(evmParser.BoolContext,0)


        def comparison_statement(self):
            return self.getTypedRuleContext(evmParser.Comparison_statementContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCondition" ):
                listener.enterCondition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCondition" ):
                listener.exitCondition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCondition" ):
                return visitor.visitCondition(self)
            else:
                return visitor.visitChildren(self)




    def condition(self):

        localctx = evmParser.ConditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_condition)
        try:
            self.state = 91
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10, 11]:
                self.enterOuterAlt(localctx, 1)
                self.state = 89
                self.bool_()
                pass
            elif token in [21, 22, 23, 25]:
                self.enterOuterAlt(localctx, 2)
                self.state = 90
                self.comparison_statement()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comparison_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RELATIONAL_OPERATOR(self):
            return self.getToken(evmParser.RELATIONAL_OPERATOR, 0)

        def id_(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(evmParser.IdContext)
            else:
                return self.getTypedRuleContext(evmParser.IdContext,i)


        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(evmParser.ValueContext)
            else:
                return self.getTypedRuleContext(evmParser.ValueContext,i)


        def getRuleIndex(self):
            return evmParser.RULE_comparison_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparison_statement" ):
                listener.enterComparison_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparison_statement" ):
                listener.exitComparison_statement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparison_statement" ):
                return visitor.visitComparison_statement(self)
            else:
                return visitor.visitChildren(self)




    def comparison_statement(self):

        localctx = evmParser.Comparison_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_comparison_statement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25]:
                self.state = 93
                self.id_()
                pass
            elif token in [21, 22, 23]:
                self.state = 94
                self.value()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 97
            self.match(evmParser.RELATIONAL_OPERATOR)
            self.state = 100
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25]:
                self.state = 98
                self.id_()
                pass
            elif token in [21, 22, 23]:
                self.state = 99
                self.value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BoolContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return evmParser.RULE_bool

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBool" ):
                listener.enterBool(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBool" ):
                listener.exitBool(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBool" ):
                return visitor.visitBool(self)
            else:
                return visitor.visitChildren(self)




    def bool_(self):

        localctx = evmParser.BoolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_bool)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            _la = self._input.LA(1)
            if not(_la==10 or _la==11):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variable_declartionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_type(self):
            return self.getTypedRuleContext(evmParser.Variable_typeContext,0)


        def id_(self):
            return self.getTypedRuleContext(evmParser.IdContext,0)


        def value(self):
            return self.getTypedRuleContext(evmParser.ValueContext,0)


        def expression(self):
            return self.getTypedRuleContext(evmParser.ExpressionContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_variable_declartion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable_declartion" ):
                listener.enterVariable_declartion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable_declartion" ):
                listener.exitVariable_declartion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable_declartion" ):
                return visitor.visitVariable_declartion(self)
            else:
                return visitor.visitChildren(self)




    def variable_declartion(self):

        localctx = evmParser.Variable_declartionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_variable_declartion)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104
            self.variable_type()
            self.state = 105
            self.id_()
            self.state = 106
            self.match(evmParser.T__11)
            self.state = 109
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.state = 107
                self.value()
                pass

            elif la_ == 2:
                self.state = 108
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variable_assignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(evmParser.IdContext,0)


        def value(self):
            return self.getTypedRuleContext(evmParser.ValueContext,0)


        def expression(self):
            return self.getTypedRuleContext(evmParser.ExpressionContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_variable_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable_assignment" ):
                listener.enterVariable_assignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable_assignment" ):
                listener.exitVariable_assignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable_assignment" ):
                return visitor.visitVariable_assignment(self)
            else:
                return visitor.visitChildren(self)




    def variable_assignment(self):

        localctx = evmParser.Variable_assignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_variable_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 111
            self.id_()
            self.state = 112
            self.match(evmParser.T__11)
            self.state = 115
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.state = 113
                self.value()
                pass

            elif la_ == 2:
                self.state = 114
                self.expression(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Variable_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return evmParser.RULE_variable_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable_type" ):
                listener.enterVariable_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable_type" ):
                listener.exitVariable_type(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariable_type" ):
                return visitor.visitVariable_type(self)
            else:
                return visitor.visitChildren(self)




    def variable_type(self):

        localctx = evmParser.Variable_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_variable_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 57344) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def term(self):
            return self.getTypedRuleContext(evmParser.TermContext,0)


        def expression(self):
            return self.getTypedRuleContext(evmParser.ExpressionContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)



    def expression(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = evmParser.ExpressionContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 30
        self.enterRecursionRule(localctx, 30, self.RULE_expression, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120
            self.term(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 127
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = evmParser.ExpressionContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_expression)
                    self.state = 122
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 123
                    _la = self._input.LA(1)
                    if not(_la==16 or _la==17):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 124
                    self.term(0) 
                self.state = 129
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class TermContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def factor(self):
            return self.getTypedRuleContext(evmParser.FactorContext,0)


        def term(self):
            return self.getTypedRuleContext(evmParser.TermContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTerm" ):
                listener.enterTerm(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTerm" ):
                listener.exitTerm(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTerm" ):
                return visitor.visitTerm(self)
            else:
                return visitor.visitChildren(self)



    def term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = evmParser.TermContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 32
        self.enterRecursionRule(localctx, 32, self.RULE_term, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self.factor()
            self._ctx.stop = self._input.LT(-1)
            self.state = 138
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = evmParser.TermContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_term)
                    self.state = 133
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 134
                    _la = self._input.LA(1)
                    if not(_la==18 or _la==19):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 135
                    self.factor() 
                self.state = 140
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class FactorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def id_(self):
            return self.getTypedRuleContext(evmParser.IdContext,0)


        def value(self):
            return self.getTypedRuleContext(evmParser.ValueContext,0)


        def expression(self):
            return self.getTypedRuleContext(evmParser.ExpressionContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFactor" ):
                listener.enterFactor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFactor" ):
                listener.exitFactor(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFactor" ):
                return visitor.visitFactor(self)
            else:
                return visitor.visitChildren(self)




    def factor(self):

        localctx = evmParser.FactorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_factor)
        try:
            self.state = 147
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [25]:
                self.enterOuterAlt(localctx, 1)
                self.state = 141
                self.id_()
                pass
            elif token in [21, 22, 23]:
                self.enterOuterAlt(localctx, 2)
                self.state = 142
                self.value()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 3)
                self.state = 143
                self.match(evmParser.T__1)
                self.state = 144
                self.expression(0)
                self.state = 145
                self.match(evmParser.T__2)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(evmParser.ID, 0)

        def getRuleIndex(self):
            return evmParser.RULE_id

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterId" ):
                listener.enterId(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitId" ):
                listener.exitId(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitId" ):
                return visitor.visitId(self)
            else:
                return visitor.visitChildren(self)




    def id_(self):

        localctx = evmParser.IdContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_id)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 149
            self.match(evmParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Print_variableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self):
            return self.getTypedRuleContext(evmParser.ValueContext,0)


        def id_(self):
            return self.getTypedRuleContext(evmParser.IdContext,0)


        def getRuleIndex(self):
            return evmParser.RULE_print_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrint_variable" ):
                listener.enterPrint_variable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrint_variable" ):
                listener.exitPrint_variable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrint_variable" ):
                return visitor.visitPrint_variable(self)
            else:
                return visitor.visitChildren(self)




    def print_variable(self):

        localctx = evmParser.Print_variableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_print_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(evmParser.T__19)
            self.state = 152
            self.match(evmParser.T__1)
            self.state = 155
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21, 22, 23]:
                self.state = 153
                self.value()
                pass
            elif token in [25]:
                self.state = 154
                self.id_()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 157
            self.match(evmParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return evmParser.RULE_value

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class StringContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a evmParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(evmParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterString" ):
                listener.enterString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitString" ):
                listener.exitString(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitString" ):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)


    class FloatContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a evmParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(evmParser.FLOAT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFloat" ):
                listener.enterFloat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFloat" ):
                listener.exitFloat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloat" ):
                return visitor.visitFloat(self)
            else:
                return visitor.visitChildren(self)


    class IntContext(ValueContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a evmParser.ValueContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(evmParser.INT, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInt" ):
                listener.enterInt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInt" ):
                listener.exitInt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInt" ):
                return visitor.visitInt(self)
            else:
                return visitor.visitChildren(self)



    def value(self):

        localctx = evmParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_value)
        try:
            self.state = 162
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [21]:
                localctx = evmParser.IntContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 159
                self.match(evmParser.INT)
                pass
            elif token in [22]:
                localctx = evmParser.FloatContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 160
                self.match(evmParser.FLOAT)
                pass
            elif token in [23]:
                localctx = evmParser.StringContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 161
                self.match(evmParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[15] = self.expression_sempred
        self._predicates[16] = self.term_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expression_sempred(self, localctx:ExpressionContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         

    def term_sempred(self, localctx:TermContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 2)
         




