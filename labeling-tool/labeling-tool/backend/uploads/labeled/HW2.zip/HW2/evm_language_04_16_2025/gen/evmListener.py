# Generated from D:/PhD/Classes/Compiler_1403_2/projects/evm_language_prototype/out/evm.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .evmParser import evmParser
else:
    from evmParser import evmParser

# This class defines a complete listener for a parse tree produced by evmParser.
class evmListener(ParseTreeListener):

    # Enter a parse tree produced by evmParser#program.
    def enterProgram(self, ctx:evmParser.ProgramContext):
        pass

    # Exit a parse tree produced by evmParser#program.
    def exitProgram(self, ctx:evmParser.ProgramContext):
        pass


    # Enter a parse tree produced by evmParser#statements.
    def enterStatements(self, ctx:evmParser.StatementsContext):
        pass

    # Exit a parse tree produced by evmParser#statements.
    def exitStatements(self, ctx:evmParser.StatementsContext):
        pass


    # Enter a parse tree produced by evmParser#statement.
    def enterStatement(self, ctx:evmParser.StatementContext):
        pass

    # Exit a parse tree produced by evmParser#statement.
    def exitStatement(self, ctx:evmParser.StatementContext):
        pass


    # Enter a parse tree produced by evmParser#if_statement.
    def enterIf_statement(self, ctx:evmParser.If_statementContext):
        pass

    # Exit a parse tree produced by evmParser#if_statement.
    def exitIf_statement(self, ctx:evmParser.If_statementContext):
        pass


    # Enter a parse tree produced by evmParser#while_statement.
    def enterWhile_statement(self, ctx:evmParser.While_statementContext):
        pass

    # Exit a parse tree produced by evmParser#while_statement.
    def exitWhile_statement(self, ctx:evmParser.While_statementContext):
        pass


    # Enter a parse tree produced by evmParser#for_statement.
    def enterFor_statement(self, ctx:evmParser.For_statementContext):
        pass

    # Exit a parse tree produced by evmParser#for_statement.
    def exitFor_statement(self, ctx:evmParser.For_statementContext):
        pass


    # Enter a parse tree produced by evmParser#for_increment.
    def enterFor_increment(self, ctx:evmParser.For_incrementContext):
        pass

    # Exit a parse tree produced by evmParser#for_increment.
    def exitFor_increment(self, ctx:evmParser.For_incrementContext):
        pass


    # Enter a parse tree produced by evmParser#for_intialization.
    def enterFor_intialization(self, ctx:evmParser.For_intializationContext):
        pass

    # Exit a parse tree produced by evmParser#for_intialization.
    def exitFor_intialization(self, ctx:evmParser.For_intializationContext):
        pass


    # Enter a parse tree produced by evmParser#block_statement.
    def enterBlock_statement(self, ctx:evmParser.Block_statementContext):
        pass

    # Exit a parse tree produced by evmParser#block_statement.
    def exitBlock_statement(self, ctx:evmParser.Block_statementContext):
        pass


    # Enter a parse tree produced by evmParser#condition.
    def enterCondition(self, ctx:evmParser.ConditionContext):
        pass

    # Exit a parse tree produced by evmParser#condition.
    def exitCondition(self, ctx:evmParser.ConditionContext):
        pass


    # Enter a parse tree produced by evmParser#comparison_statement.
    def enterComparison_statement(self, ctx:evmParser.Comparison_statementContext):
        pass

    # Exit a parse tree produced by evmParser#comparison_statement.
    def exitComparison_statement(self, ctx:evmParser.Comparison_statementContext):
        pass


    # Enter a parse tree produced by evmParser#bool.
    def enterBool(self, ctx:evmParser.BoolContext):
        pass

    # Exit a parse tree produced by evmParser#bool.
    def exitBool(self, ctx:evmParser.BoolContext):
        pass


    # Enter a parse tree produced by evmParser#variable_declartion.
    def enterVariable_declartion(self, ctx:evmParser.Variable_declartionContext):
        pass

    # Exit a parse tree produced by evmParser#variable_declartion.
    def exitVariable_declartion(self, ctx:evmParser.Variable_declartionContext):
        pass


    # Enter a parse tree produced by evmParser#variable_assignment.
    def enterVariable_assignment(self, ctx:evmParser.Variable_assignmentContext):
        pass

    # Exit a parse tree produced by evmParser#variable_assignment.
    def exitVariable_assignment(self, ctx:evmParser.Variable_assignmentContext):
        pass


    # Enter a parse tree produced by evmParser#variable_type.
    def enterVariable_type(self, ctx:evmParser.Variable_typeContext):
        pass

    # Exit a parse tree produced by evmParser#variable_type.
    def exitVariable_type(self, ctx:evmParser.Variable_typeContext):
        pass


    # Enter a parse tree produced by evmParser#expression.
    def enterExpression(self, ctx:evmParser.ExpressionContext):
        pass

    # Exit a parse tree produced by evmParser#expression.
    def exitExpression(self, ctx:evmParser.ExpressionContext):
        pass


    # Enter a parse tree produced by evmParser#term.
    def enterTerm(self, ctx:evmParser.TermContext):
        pass

    # Exit a parse tree produced by evmParser#term.
    def exitTerm(self, ctx:evmParser.TermContext):
        pass


    # Enter a parse tree produced by evmParser#factor.
    def enterFactor(self, ctx:evmParser.FactorContext):
        pass

    # Exit a parse tree produced by evmParser#factor.
    def exitFactor(self, ctx:evmParser.FactorContext):
        pass


    # Enter a parse tree produced by evmParser#id.
    def enterId(self, ctx:evmParser.IdContext):
        pass

    # Exit a parse tree produced by evmParser#id.
    def exitId(self, ctx:evmParser.IdContext):
        pass


    # Enter a parse tree produced by evmParser#print_variable.
    def enterPrint_variable(self, ctx:evmParser.Print_variableContext):
        pass

    # Exit a parse tree produced by evmParser#print_variable.
    def exitPrint_variable(self, ctx:evmParser.Print_variableContext):
        pass


    # Enter a parse tree produced by evmParser#int.
    def enterInt(self, ctx:evmParser.IntContext):
        pass

    # Exit a parse tree produced by evmParser#int.
    def exitInt(self, ctx:evmParser.IntContext):
        pass


    # Enter a parse tree produced by evmParser#float.
    def enterFloat(self, ctx:evmParser.FloatContext):
        pass

    # Exit a parse tree produced by evmParser#float.
    def exitFloat(self, ctx:evmParser.FloatContext):
        pass


    # Enter a parse tree produced by evmParser#string.
    def enterString(self, ctx:evmParser.StringContext):
        pass

    # Exit a parse tree produced by evmParser#string.
    def exitString(self, ctx:evmParser.StringContext):
        pass



del evmParser